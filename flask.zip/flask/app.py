from flask import Flask, render_template

app = Flask (__name__)

@app.route("/")
def inicio():
    return render_template("index.html")

@app.route("/sobre.html")
def sobre():
    return render_template("sobre.html")

@app.route("/contato.html")
def contato():
    return render_template("contato.html")

@app.route("/imagens.html")
def imagens():
    list = []
    with open("epic.txt", "r") as archive:
        for lines in archive:
            sentence = lines.split(";")
            name = sentence[0]
            price = sentence [1]
            image = sentence [2]

            product = {

                "name": name,
                "price": price,
                "image": image

            }

            list.append(product)

    return render_template("imagens.html", list=list)



app.run(debug = True)